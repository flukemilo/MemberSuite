﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace _reflection
{
    class Reflection
    {
        static void Main(string[] args)
        {
         //     Assembly mscorlib = typeof(string).Assembly;                    // test
                Assembly myAssembly = Assembly.GetExecutingAssembly();
                bool noneFound = true;      

         //     foreach (Type type in mscorlib.GetTypes())                      // test
                foreach (Type type in myAssembly.GetTypes())
                {
                    foreach (PropertyInfo x in type.GetProperties())
                    {

                     string AccessModType = ReflectionExt.Accessmodifier(x).ToString();

                     if (AccessModType == "Protected")
         //          if (AccessModType == "Public")                             // test
                        {
                            Console.WriteLine(AccessModType);
                            noneFound = false;
                        }
                     }
            }

            if (noneFound == true)
            {
                Console.WriteLine("There were no protected properties located in the running assembly.");
            }
            Console.ReadLine();                                                 // read result
        }
    }

    public static class ReflectionExt
    {
        public static readonly List<AccessModifier> AccessModifiers = new List<AccessModifier>
    {
        AccessModifier.Private,
        AccessModifier.Protected,
        AccessModifier.Internal,
        AccessModifier.Public
    };

        public static AccessModifier Accessmodifier(this PropertyInfo propertyInfo)
        {
            if (propertyInfo.SetMethod == null)
                return propertyInfo.GetMethod.Accessmodifier();
            if (propertyInfo.GetMethod == null)
                return propertyInfo.SetMethod.Accessmodifier();
            var max = Math.Max(AccessModifiers.IndexOf(propertyInfo.GetMethod.Accessmodifier()),
                AccessModifiers.IndexOf(propertyInfo.SetMethod.Accessmodifier()));
            return AccessModifiers[max];
        }

        public static AccessModifier Accessmodifier(this MethodInfo methodInfo)
        {
            if (methodInfo.IsPrivate)
                return AccessModifier.Private;
            if (methodInfo.IsFamily)
                return AccessModifier.Protected;
            if (methodInfo.IsAssembly)
                return AccessModifier.Internal;
            if (methodInfo.IsPublic)
                return AccessModifier.Public;
            throw new ArgumentException("Did not find access modifier", "methodInfo");
        }

        public enum AccessModifier
        {
            Private,
            Protected,
            Internal,
            Public
        }
    }


}



