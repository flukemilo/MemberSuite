﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _FruitRefactor
{

    class FruitRefactor
    {

       public List<Fruit> Collection = new List<Fruit>();

        static void Main(string[] args)
        {
            
        }
        
        public T AddFruit<T>(T f) where T : Fruit

        {
            if (f.Seeds > 0)
                Collection.Add(f);

            return (T)Collection.Next;
        }

    }

    class Fruit 
    {
        public int Seeds { get; set; }
    }
}








