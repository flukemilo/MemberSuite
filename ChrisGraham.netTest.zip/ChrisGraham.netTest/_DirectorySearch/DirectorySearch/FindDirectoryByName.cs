﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectorySearch
{
    public class FindDirectoryByName
    {
        public static string searchString;

        public static bool isNotFound = true;

        public static void FDBN(string[] args)
        {

          //  string[] args = { "testdir" };  //test

            if (args.Count() == 1)

            {
                searchString = string.Concat(args);

            } else { 

                Console.WriteLine("Please enter one search criterion for the directory for which you're searching.");
                Console.ReadLine();
                return;
        }

            string[] startingDir = new string[] { @"." };

            foreach (string path in startingDir)
            {
                if (File.Exists(path))
                {
                    ProcessFile(path);

                } else if (Directory.Exists(path)) {

                    ProcessDirectory(path);

                } else {

                   Console.WriteLine("{0} is not a valid file or directory.", path);
                }
            }

            if (isNotFound)
            {
                Console.WriteLine("File not found on basis of name or fragment thereof.");
            }

     //     Console.ReadKey();      //      test

        }

        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);

            foreach (string subdirectory in subdirectoryEntries)
            {

                if (Path.GetFileNameWithoutExtension(subdirectory) == searchString)

                {

                    if (Path.GetDirectoryName(subdirectory) == ".")
                    {
                        Console.WriteLine("Found \"{0}\" under current directory.", searchString);

                        isNotFound = false;

                    }
                    else {

                        Console.WriteLine("Found \"{0}\" under directory \"{1}\"", searchString, Path.GetDirectoryName(subdirectory));
                   }
                }

                ProcessDirectory(subdirectory);
            }
        }

        public static void ProcessFile(string path)
        {

        }
    }
}






