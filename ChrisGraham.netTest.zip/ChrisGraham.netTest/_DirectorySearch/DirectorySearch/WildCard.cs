﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace DirectorySearch
{
    public class WildCard
    {
        public static string searchString;

        public static IList<string> dirList = new List<string>();

          public static void WC(string[] args)
          //    public static void Main()                       //test
        {

        //    string[] args = { "test" };  //test

            if (args.Count() == 1)

            {
                searchString = string.Concat(args);

            }  else {

                Console.WriteLine("Please enter one search criterion for the directory for which you're searching.");
                Console.ReadLine();
                return;
            }

            string[] startingDir = new string[] { @"." };

            foreach (string path in startingDir)
            {
                if (File.Exists(path))
                {
                    ProcessFile(path);

                }
                else if (Directory.Exists(path))
                {
                    ProcessDirectory(path);

                }  else   {

                    Console.WriteLine("{0} is not a valid file or directory.", path);
                }
            }
            
            foreach (string x in dirList)
            {
                Console.WriteLine(x);
            }

            if (dirList.Count() == 0)
            {

                Console.WriteLine("Could not locate any files by this name or part.");

            }

         //   Console.ReadLine();               test

        }

        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);

            foreach (string fileName in fileEntries)
            {
                string currentDirectoryDirectory = Directory.GetCurrentDirectory();

                int CDLength = currentDirectoryDirectory.Length;

                int FNLength = fileName.Length;

                string dn = Directory.GetDirectoryRoot(fileName);

                ProcessFile(fileName);
            }

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);

            foreach (string subdirectory in subdirectoryEntries)
            {
                ProcessDirectory(subdirectory);
            }
        }

        public static void ProcessFile(string fileName)
        {

            if (fileName.Contains(searchString))
            {
                dirList.Add(fileName.ToString());
            };
        }
    }
}








