﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectorySearch
{
    public class GetSubdirectoryCount
    {

        public static int subDirCount = 0;

        public static void GSC(string[] args)
        {

            string[] startingDir = new string[] { Directory.GetCurrentDirectory() };       

            foreach (string path in startingDir)
            {
                if (File.Exists(path))
                {
                    ProcessFile(path);

                } else if (Directory.Exists(path)) {

                    ProcessDirectory(path);

                } else {

                   Console.WriteLine("{0} is not a valid file or directory.", path);
                }
            }

            Console.WriteLine("There are {0} total directory and/or subdirectories", subDirCount);

      //      Console.ReadLine();               test

        }

        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);

            foreach (string subdirectory in subdirectoryEntries)
            {
                subDirCount++;

                ProcessDirectory(subdirectory);
            }
        }

        public static void ProcessFile(string path)
        {

        }
    }
}






