﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectorySearch
{ 
        public class ListAllDirectories
        {
   
    //    public static void LAD(string[] args)
        public static void LAD()

        {

            string[] arg = new string[] { @"C:\" };
        
                foreach (string path in arg)
                {
                    if (File.Exists(path))
                    {

                        ProcessFile(path);
                    }
                    else if (Directory.Exists(path))
                    {

                        ProcessDirectory(path);
                    }
                    else
                    {
                        Console.WriteLine("{0} is not a valid file or directory.", path);
                    }
                }

       //     Console.ReadLine();                   // test

        }


        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);

            foreach (string subdirectory in subdirectoryEntries) { 
                    Console.WriteLine("this is a SUB" + subdirectory);
                try
                {
                    ProcessDirectory(subdirectory);
                } catch 
                {
                    Console.WriteLine("Can't access this {0}", subdirectory);
                }
            }
        }

            public static void ProcessFile(string path)
            {
                Console.WriteLine("This is a FILE '{0}'.", path);
            }
        }
    }






