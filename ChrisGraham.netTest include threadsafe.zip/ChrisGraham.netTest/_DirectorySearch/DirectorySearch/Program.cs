﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectorySearch
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(@"Press ""1"" to list all directories.");
            Console.WriteLine(@"Press ""2"" to find a directory by name.");
            Console.WriteLine(@"Press ""3"" to get a count of all directories and subs.");
            Console.WriteLine(@"Press ""4"" to find all occurances by filename or part of.");

            do
            {
                    while (!Console.KeyAvailable)
                    {

                    ConsoleKeyInfo info = Console.ReadKey(true);

                        switch (info.KeyChar){

                        case '1':
                            ListAllDirectories.LAD();
                            break;

                        case '2':
                            Console.WriteLine("Enter directory name:");
                            string directoryInput = Console.ReadLine();
                            string[] directoryInputArray = new string[]{ directoryInput.ToString()};
                            FindDirectoryByName.FDBN(directoryInputArray);
                             break;

                        case '3':
                            string[] startingDir = new string[] { Directory.GetCurrentDirectory() };
                            GetSubdirectoryCount.GSC(startingDir);
                            break;


                        case '4':
                            Console.WriteLine("Enter file name or part of:");
                            string fileNameInput = Console.ReadLine();
                            string[] fileNameInputArray = new string[] { fileNameInput.ToString() };
                            WildCard.WC(fileNameInputArray);
                            break;
                        }

                    }
                } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
            }
        }
}
