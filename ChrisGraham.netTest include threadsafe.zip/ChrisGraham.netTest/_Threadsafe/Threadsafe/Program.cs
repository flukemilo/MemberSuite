﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threadsafe
{
    class Program

    protected const int MAX_MESSAGES = 100;
    protected int messageCounter = 0;
    object _lock = new object;


    public void ProcessMessage(Message msg)
    {
        lock (_lock)
        {
            if (msg.IsValid() && messageCounter < MAX_MESSAGES)
            {
                Msg.File();
                messageCounter++;
            }
        }
    }
